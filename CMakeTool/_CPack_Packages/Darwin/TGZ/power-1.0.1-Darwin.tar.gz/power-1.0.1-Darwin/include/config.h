#define HAVE_POW
#define power_VERSION_MAJOR 1
#define power_VERSION_MINOR 0
